$(function(){
    $('.mask-fone').mask('(00) 0000-0000');
    $('.mask-cel').mask('(00) 00000-0000');
    $('.mask-data').mask('00/00/0000');
});


